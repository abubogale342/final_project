from flask import (
    Blueprint, flash, g, redirect, render_template, request, url_for
)
from werkzeug.exceptions import abort

from app.auth import login_required
from app.db import get_db

bp = Blueprint('hotel', __name__)

@bp.route('/hotel/<int:hotel_id>')
def index(hotel_id):
    db = get_db()
    hotel = db.execute(
        'SELECT hotel.id, hotel_name, phone, created, location'
        ' FROM menu WHERE id = ?'
        ' ORDER BY created DESC',
        (hotel_id,)
    ).fetchall()
    return render_template('hotel/index.html', hotel=hotel)

@bp.route('/hotels')
def hotel():
    db = get_db()
    hotels = db.execute(
        'SELECT hotel.id, hotel_name, phone, created, location'
        ' FROM hotel'
        ' ORDER BY created DESC',
    ).fetchall()
    return render_template('hotel/index.html', hotels=hotels)


@bp.route('/hotel/create', methods=('GET', 'POST'))
@login_required
def create():
    if request.method == 'POST':
        hotel = request.form['hotel_name']
        phone = request.form['phone_no']
        location = request.form['location']
        error = None

        if not hotel:
            error = 'Title is required.'

        if error is not None:
            flash(error)
        else:
            db = get_db()
            db.execute(
                'INSERT INTO hotel (hotel_name, phone, location)'
                ' VALUES (?, ?, ?)',
                (hotel, phone, location)
            )
            db.commit()
            return redirect(url_for('hotel.hotel'))

    return render_template('hotel/create.html')

def get_hotel(id):
    hotel = get_db().execute(
        'SELECT *'
        ' FROM hotel'
        ' WHERE id = ?',
        (id,)
    ).fetchone()

    if hotel is None:
        hotel = {}
        hotel['id'] = 0;
        hotel['account'] = 3;
        hotel['hotel_name'] = "Unknown";

    return hotel

@bp.route('/post/<int:id>/update', methods=('GET', 'POST'))
@login_required
def update(id):
    post = get_post(id)

    if request.method == 'POST':
        title = request.form['title']
        body = request.form['body']
        error = None

        if not title:
            error = 'Title is required.'

        if error is not None:
            flash(error)
        else:
            db = get_db()
            db.execute(
                'UPDATE post SET title = ?, body = ?'
                ' WHERE id = ?',
                (title, body, id)
            )
            db.commit()
            return redirect(url_for('blog.index'))

    return render_template('blog/update.html', post=post)

@bp.route('/<int:id>/delete', methods=('POST',))
@login_required
def delete(id):
    get_post(id)
    db = get_db()
    db.execute('DELETE FROM post WHERE id = ?', (id,))
    db.commit()
    return redirect(url_for('blog.index'))