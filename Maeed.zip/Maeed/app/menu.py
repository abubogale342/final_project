from flask import (
    Blueprint, flash, g, redirect, render_template, request, url_for
)
from werkzeug.exceptions import abort

from app.auth import login_required
from app.db import get_db

bp = Blueprint('menu', __name__)

@bp.route('/menu/hotel/<int:hotel_id>')
def index(hotel_id):
    db = get_db()
    menu = db.execute(
        'SELECT menu.id, food_name, price, created, hotel_id'
        ' FROM menu WHERE hotel_id = ? AND available=1'
        ' ORDER BY created DESC',
        (hotel_id,)
    ).fetchall()
    len_menu = len(menu)
    return render_template('menu/index.html', menu=menu, len_menu=len_menu)

@bp.route('/menu', methods=('GET', 'POST'))
def menu():
    db = get_db()
    menu = db.execute(
        'SELECT menu.id, food_name, price, description, created'
        ' FROM menu'
        ' ORDER BY created DESC',
    ).fetchall()
    len_menu = len(menu)
    return render_template('menu/index.html', menu=menu, len_menu=len_menu)


@bp.route('/menu/create', methods=('GET', 'POST'))
@login_required
def create():
    if request.method == 'POST':
        hotel = request.form['hotel']
        food = request.form['food_name']
        price = request.form['price']
        description = request.form['description']
        available = request.form['available']
        error = None

        if not food:
            error = 'Title is required.'

        if error is not None:
            flash(error)
        else:
            db = get_db()
            db.execute(
                'INSERT INTO menu (hotel_id, food_name, price, description, available)'
                ' VALUES (?, ?, ?, ?, ?)',
                (hotel, food, price, description, available)
            )
            db.commit()
            return redirect(url_for('menu.menu'))

    return render_template('menu/create.html')

def get_menu(id):
    menu = get_db().execute(
        'SELECT *'
        ' FROM menu'
        ' WHERE id = ?',
        (id,)
    ).fetchone()

    if menu is None:
        abort(404, "Post id {0} doesn't exist.".format(id))

    return menu

@bp.route('/menu/edit', methods=('GET', 'POST'))
@login_required
def edit():

    if request.method == 'POST':
        meal_id = request.form['e_meal_id']
        food = request.form['e_food_name']
        price = request.form['e_food_price']
        description = request.form['e_food_description']
        error = None

        if error is not None:
            flash(error)
        else:
            db = get_db()
            db.execute(
                'UPDATE menu SET food_name = ?, price = ?, description = ?'
                ' WHERE id = ?',
                (food, price, description, meal_id)
            )
            db.commit()
            return redirect(url_for('menu.menu'))

    return render_template('blog/update.html', post=post)

@bp.route('/<int:id>/delete', methods=('POST',))
@login_required
def delete(id):
    get_post(id)
    db = get_db()
    db.execute('DELETE FROM post WHERE id = ?', (id,))
    db.commit()
    return redirect(url_for('blog.index'))