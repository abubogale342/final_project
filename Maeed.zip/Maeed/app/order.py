from flask import (
    Blueprint, flash, g, redirect, render_template, request, url_for
)
from werkzeug.exceptions import abort

from app.auth import login_required
from app.auth import account_manager
from app.auth import get_user
from app.db import get_db
from app.menu import get_menu
from app.hotel import get_hotel

bp = Blueprint('order', __name__)

@bp.route('/orders/profile/<user_id>')
@login_required
def myOrder(user_id):
    ret = []
    db = get_db()
    orders_ = db.execute(
        'SELECT *'
        ' FROM orders WHERE user_id = ? GROUP BY created, table_no'
        ' ORDER BY created DESC',(user_id)
        )
    db.commit()

    orders = list(orders_)

    for order in orders:
        ret_dict = {}
        ret_dict['id'] = order['id']
        ret_dict['user'] = get_user(order['user_id'])
        ret_dict['hotel'] = get_hotel(order['hotel_id'])
        ret_dict['table_no'] = order['table_no']
        ret_dict['created'] = order['created']
        ret_dict['approved'] = order['approved']
        
        meal_slist = str(order['meal_id']).strip(',')
        meal_list = meal_slist.split(":")

        meal = []
        for i in range(1,len(meal_list)):
            meal_ = meal_list[i].split(",")
            meal_id = meal_[0]
            meal_quantity = meal_[1]

            _meal = {}
            _meal = dict(get_menu(meal_id)).copy()
            _meal['price'] = int(meal_quantity) * int(_meal['price'])
            _meal['quantity'] = meal_quantity

            meal.append(_meal)
            #rets = rets + ">"+meal_id+" -- "+meal_quantity+str(meal['food_name'])

        ret_dict['meal'] = meal
        ret.append(ret_dict)

    #return str(r)
    return render_template('order/index.html', ret_list=ret)

@bp.route('/orders', methods=('GET', 'POST'))
@login_required
@account_manager
def orders():
    ret = []
    orders = []

    db = get_db()
    orders_ = db.execute(
        'SELECT *'
        ' FROM orders GROUP BY created, table_no'
        ' ORDER BY created DESC',
    ).fetchall()
    db.commit()

    orders = list(orders_)

    if request.method == 'POST':
        status = request.form['status']
        if status == '0':
            db = get_db()
            orders_ = db.execute(
                'SELECT *'
                ' FROM orders GROUP BY created, table_no'
                ' ORDER BY created DESC',
            ).fetchall()

            orders = list(orders_)

        elif status == '1':
            db = get_db()
            orders_ = db.execute(
                'SELECT *'
                ' FROM orders WHERE approved=0 GROUP BY created, table_no'
                ' ORDER BY created DESC',
            ).fetchall()

            orders = list(orders_)
            
        elif status == '2':
            db = get_db()
            orders_ = db.execute(
                'SELECT *'
                ' FROM orders WHERE approved=1 GROUP BY created, table_no'
                ' ORDER BY created DESC',
            ).fetchall()

            orders = list(orders_)
        else:
            db = get_db()
            orders_ = db.execute(
                'SELECT *'
                ' FROM orders GROUP BY created, table_no'
                ' ORDER BY created DESC',
            ).fetchall()

            orders = list(orders_)


    for order in orders:
        ret_dict = {}
        ret_dict['id'] = order['id']
        ret_dict['user'] = get_user(order['user_id'])
        ret_dict['table_no'] = order['table_no']
        ret_dict['created'] = order['created']
        ret_dict['approved'] = order['approved']
        
        meal_slist = str(order['meal_id']).strip(',')
        meal_list = meal_slist.split(":")

        meal = []
        for i in range(1,len(meal_list)):
            meal_ = meal_list[i].split(",")
            meal_id = meal_[0]
            meal_quantity = meal_[1]

            _meal = {}
            _meal = dict(get_menu(meal_id)).copy()
            _meal['price'] = int(meal_quantity) * int(_meal['price'])
            _meal['quantity'] = meal_quantity

            meal.append(_meal)
            #rets = rets + ">"+meal_id+" -- "+meal_quantity+str(meal['food_name'])

        ret_dict['meal'] = meal
        ret.append(ret_dict)

    #return str(r)
    return render_template('order/index.html', ret_list=ret)

@bp.route('/order/create', methods=('GET', 'POST'))
def create():
    if request.method == 'POST':
        table = request.form['table']
        cart = request.form['cart']
        user = request.form['user']
        ret = "RET :::  "
        data = "D"

        if user == "":
            user = 0

        req = dict(request.form).copy()

        for i in range(1,int(cart)+1):
            res = req.get('cart_'+str(i)+'_meal', "NA")
            if res != "NA":
                meal = request.form['cart_'+str(i)+'_meal']
                quantity = request.form['cart_'+str(i)+'_quantity']

                ret = ret + str(i) + " --- "+ str(meal) + " - " +str(quantity) + " :::  "
                data = data+":"+str(meal)+","+str(quantity)

        db = get_db()
        db.execute(
            'INSERT INTO orders (user_id, meal_id, table_no, amount, approved)'
            ' VALUES (?, ?, ?, ?, ?)',
            (user, data, table, 0, 0)
        )
        db.commit()
        return redirect(url_for('page.success'))


@bp.route('/orders/accept', methods=('GET', 'POST'))
@login_required
@account_manager
def accept():
    if request.method == 'POST':
        order_id = request.form['order_id']
        db = get_db()
        db.execute(
            'UPDATE orders SET approved=1 WHERE id = ?',(order_id,)
            )
        db.commit()
        return redirect(url_for('order.orders'))

    return render_template('order/index.html')
  

@bp.route('/<int:id>/delete', methods=('POST',))
@login_required
def delete(id):
    get_post(id)
    db = get_db()
    db.execute('DELETE FROM post WHERE id = ?', (id,))
    db.commit()
    return redirect(url_for('blog.index'))