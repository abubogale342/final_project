function ShowPWD(pwdfield)
{
	var pwdfield_obj = document.getElementById(pwdfield);
	var pwdshow = pwdfield_obj.id+"_show";
	var pwdsm_obj = document.getElementById(pwdshow);
	pwdsm_obj.onclick=function(){showpwdchars(pwdsm_obj,pwdfield_obj); }	
}
function generatePWD(pwdfield_obj)
{
    var maxAlpha = 26;
	var strSymbols="~!@#$%^&*(){}?><`=-|][";
	var password='';
	for(i=0;i<3;i++)
	{
		password = String.fromCharCode("a".charCodeAt(0) + getRand(maxAlpha));
	}
	for(i=0;i<3;i++)
	{
		password += String.fromCharCode("A".charCodeAt(0) + getRand(maxAlpha));
	}
	for(i=0;i<3;i++)
	{
		password += String.fromCharCode("0".charCodeAt(0) + getRand(10));
	}
	for(i=0;i<4;i++)
	{
		password += strSymbols.charAt(getRand(strSymbols.length));
	}

	password = shuffleString(password);
	password = shuffleString(password);
	password = shuffleString(password);

	pwdfield_obj.value = password;
	PasswordStrength(pwdfield_obj);
}
function showpwdchars(pwdsm_obj,pwdfield_obj)
{
	pwdshow = pwdfield_obj.id+"_show";
	pwdmask = pwdfield_obj.id+"_mask";
	
	pwdsm_id = pwdsm_obj.id;
 	
	if(pwdsm_id == pwdshow)
	{
		pwdfield_obj.type = "text";
		pwdsm_obj.innerHTML = "Mask";
		pwdsm_obj.id = pwdmask;
		pwdfield_obj.focus();
	}
	else 
	if(pwdsm_id == pwdmask)
	{
		pwdfield_obj.type = "password";
		pwdsm_obj.innerHTML = "Show";
		pwdsm_obj.id = pwdshow;
		pwdfield_obj.focus();		
	}

}
function PWDStrength(pwdfield)
{
	var pwdfield_obj = document.getElementById(pwdfield);
	var pwd = pwdfield_obj.value;
	var pwdfield_id = pwdfield_obj.id;
	
	var sthbar = pwdfield_id+"_sthbar";
	var sthstr = pwdfield_id+"_sthstr";
	
	var colors = new Array();
	colors[0] = "#cccccc";
	colors[1] = "#ff0000";
	colors[2] = "#ff5f5f";
	colors[3] = "#56e500";
	colors[4] = "#4dcd00";
	colors[5] = "#399800";
	
	var desc = new Array();
	desc[0] = "";
	desc[1] = "weak";
	desc[2] = "medium";
	desc[3] = "good";
	desc[4] = "strong";
	desc[5] = "secure";

	var score   = 0;
	
	if (pwd.length > 6) {score++;}

	if ( ( pwd.match(/[a-z]/) ) && 
	     ( pwd.match(/[A-Z]/) ) ) {score++;}

	if (pwd.match(/\d+/)){ score++;}

	if ( pwd.match(/[^a-z\d]+/) )	{score++};

	if (pwd.length > 12){ score++;}
	
	var color=colors[score];
	var strengthdiv = document.getElementById(sthbar);
	
	strengthdiv.style.background=colors[score];
	
	if (pwd.length <= 0)
	{ 
		strengthdiv.style.width=0; 
	}
	else
	{
		strengthdiv.style.width=(score+1)*10+'px';
	}

	var strengthstrdiv = document.getElementById(sthstr);
	strengthstrdiv.innerHTML = desc[score];

	pwdfield_obj.onkeyup = function(){PWDStrength(pwdfield); }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


/**********************************************************************************************************************************

					< < <	- - - - - - - - - -	 > > >		VALIDATION		< < <   - - - - - - - - - -   > > >

**********************************************************************************************************************************/

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function Validation(frmname)
{
	alert("frmname");
//	this.formobj=document.forms[frmname];
//	if(!this.formobj)
//	{
//		alert("Error: couldnot get Form object "+frmname);
//		return;
//	}
//	this.formobj.onsubmit=function(){this.validateInput = validateInput}
}
	
function validateInput(strValidateStr,objValue,strError) 
{ 
    var ret = true;
    var epos = strValidateStr.search("="); 
    var  command  = ""; 
    var  cmdvalue = ""; 
    if(epos >= 0) 
    { 
     command  = strValidateStr.substring(0,epos); 
     cmdvalue = strValidateStr.substr(epos+1); 
    } 
    else 
    { 
     command = strValidateStr; 
    } 
    switch(command) 
    { 
        case "req": 
        case "required": 
        { 
			ret = TestRequiredInput(objValue,strError)
           break;             
        }//case required 
        case "maxlength": 
        case "maxlen": 
          { 
          ret = TestMaxLen(objValue,cmdvalue,strError)
             break; 
          }//case maxlen 
        case "minlength": 
        case "minlen": 
           { 
          ret = TestMinLen(objValue,cmdvalue,strError)
             break; 
            }//case minlen 
        case "alnum": 
        case "alphanumeric": 
           { 
            ret = TestInputType(objValue,"[^A-Za-z0-9]",strError, 
                  objValue.name+": Only alpha-numeric characters allowed ");
            break; 
           }
        case "alnum_s": 
        case "alphanumeric_space": 
           { 
            ret = TestInputType(objValue,"[^A-Za-z0-9\\s]",strError, 
                  objValue.name+": Only alpha-numeric characters and space allowed ");
            break; 
           }         
        case "num": 
        case "numeric": 
           { 
                ret = TestInputType(objValue,"[^0-9]",strError, 
                  objValue.name+": Only digits allowed ");
                break;               
           }
        case "alphabetic": 
        case "alpha": 
           { 
                ret = TestInputType(objValue,"[^A-Za-z]",strError, 
                  objValue.name+": Only alphabetic characters allowed ");
                break; 
           }
        case "alphabetic_space": 
        case "alpha_s": 
           { 
                ret = TestInputType(objValue,"[^A-Za-z\\s]",strError, 
                  objValue.name+": Only alphabetic characters and space allowed ");
                break; 
           }
        case "email": 
          { 
            ret = TestEmail(objValue,strError);
               break; 
          }
        case "lt": 
        case "lessthan": 
         { 
            ret = TestLessThan(objValue,cmdvalue,strError);
              break; 
         }
        case "gt": 
        case "greaterthan": 
         { 
         ret = TestGreaterThan(objValue,cmdvalue,strError);
            break; 
         }//case greaterthan 
        case "regexp": 
         { 
         ret = TestRegExp(objValue,cmdvalue,strError);
           break; 
         }
        case "dontselect": 
         { 
          ret = TestDontSelect(objValue,cmdvalue,strError)
             break; 
         }
      case "dontselectchk":
      {
         ret = TestDontSelectChk(objValue,cmdvalue,strError)
         break;
      }
      case "shouldselchk":
      {
         ret = TestShouldSelectChk(objValue,cmdvalue,strError)
         break;
      }
      case "selone_radio":
      {
         ret = TestSelectOneRadio(objValue,strError);
          break;
      }
      case "file_extn":
      {
         ret = TestFileExtension(objValue,cmdvalue,strError);
         break;
      }      
    }//switch 
   return ret;
}
function TestRequiredInput(objValue,strError)
{
	alert("d");
 var ret = true;
    if(eval(objValue.value.length) == 0) 
    { 
		if(!strError || strError.length ==0) 
		{ 
			strError = objValue.name + " : Required Field"; 
		} 
		document.this.formobj.name+"_"objValue.name+"_errorloc".innerHTML="strError";
		ret=false; 
    } 
return ret;
}