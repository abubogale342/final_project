/*
  -------------------------------------------------------------------------
            JavaScript Form Validator (gen_validatorv31.js)
              Version 3.1
   Copyright (C) 2003-2008 JavaScript-Coder.com. All rights reserved.
   You can freely use this script in your Web pages.
   You may adapt this script for your own needs, provided these opening credit
    lines are kept intact.
      
   The Form validation script is distributed free from JavaScript-Coder.com
   For updates, please visit:
   http://www.javascript-coder.com/html-form/javascript-form-validation.phtml
   
   Questions & comments please send to support@javascript-coder.com
  -------------------------------------------------------------------------  
*/
function ShowPWD(pwdfield)
{
	var pwdfield_obj = document.getElementById(pwdfield);
	var pwdshow = pwdfield_obj.id+"_show";
	var pwdsm_obj = document.getElementById(pwdshow);
	pwdsm_obj.onclick=function(){showpwdchars(pwdsm_obj,pwdfield_obj); }	
}
function generatePWD(pwdfield_obj)
{
    var maxAlpha = 26;
	var strSymbols="~!@#$%^&*(){}?><`=-|][";
	var password='';
	for(i=0;i<3;i++)
	{
		password = String.fromCharCode("a".charCodeAt(0) + getRand(maxAlpha));
	}
	for(i=0;i<3;i++)
	{
		password += String.fromCharCode("A".charCodeAt(0) + getRand(maxAlpha));
	}
	for(i=0;i<3;i++)
	{
		password += String.fromCharCode("0".charCodeAt(0) + getRand(10));
	}
	for(i=0;i<4;i++)
	{
		password += strSymbols.charAt(getRand(strSymbols.length));
	}

	password = shuffleString(password);
	password = shuffleString(password);
	password = shuffleString(password);

	pwdfield_obj.value = password;
	PasswordStrength(pwdfield_obj);
}
function showpwdchars(pwdsm_obj,pwdfield_obj)
{
	pwdshow = pwdfield_obj.id+"_show";
	pwdmask = pwdfield_obj.id+"_mask";
	
	pwdsm_id = pwdsm_obj.id;
 	
	if(pwdsm_id == pwdshow)
	{
		pwdfield_obj.type = "text";
		pwdsm_obj.innerHTML = "Mask";
		pwdsm_obj.id = pwdmask;
		pwdfield_obj.focus();
	}
	else 
	if(pwdsm_id == pwdmask)
	{
		pwdfield_obj.type = "password";
		pwdsm_obj.innerHTML = "Show";
		pwdsm_obj.id = pwdshow;
		pwdfield_obj.focus();		
	}

}
function PWDStrength(pwdfield)
{
	var pwdfield_obj = document.getElementById(pwdfield);
	var pwd = pwdfield_obj.value;
	var pwdfield_id = pwdfield_obj.id;
	
	var sthbar = pwdfield_id+"_sthbar";
	var sthstr = pwdfield_id+"_sthstr";
	
	var colors = new Array();
	colors[0] = "#cccccc";
	colors[1] = "#ff0000";
	colors[2] = "#ff5f5f";
	colors[3] = "#56e500";
	colors[4] = "#4dcd00";
	colors[5] = "#399800";
	
	var desc = new Array();
	desc[0] = "";
	desc[1] = "weak";
	desc[2] = "medium";
	desc[3] = "good";
	desc[4] = "strong";
	desc[5] = "secure";

	var score   = 0;
	
	if (pwd.length > 1) {score++;}

	if ( ( pwd.match(/[a-z]/) ) && 
	     ( pwd.match(/[A-Z]/) ) ) {score++;}

	if (pwd.match(/\d+/)){ score++;}

	if ( pwd.match(/[^a-z\d]+/) )	{score++};

	if (pwd.length > 8){ score++;}
	
	var color=colors[score];
	var strengthdiv = document.getElementById(sthbar);
	
	strengthdiv.style.background=colors[score];
	
	if (pwd.length <= 0)
	{ 
		strengthdiv.style.width=0; 
	}
	else
	{
		strengthdiv.style.width=(score+1)*10+'px';
	}

	var strengthstrdiv = document.getElementById(sthstr);
	strengthstrdiv.innerHTML = desc[score];

	pwdfield_obj.onkeyup = function(){PWDStrength(pwdfield); }
}

/*
   Copyright (C) 2003-2008 JavaScript-Coder.com . All rights reserved.
*/